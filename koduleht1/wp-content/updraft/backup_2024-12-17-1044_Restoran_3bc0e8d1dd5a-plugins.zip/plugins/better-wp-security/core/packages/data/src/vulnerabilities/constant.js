export const STORE_NAME = 'ithemes-security/vulnerabilities';
export const path = '/ithemes-security/v1/site-scanner/vulnerabilities';
