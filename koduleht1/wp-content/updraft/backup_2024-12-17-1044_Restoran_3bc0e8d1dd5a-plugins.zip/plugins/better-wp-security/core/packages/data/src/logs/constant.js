export const STORE_NAME = 'ithemes-security/logs';
export const path = '/ithemes-security/v1/logs';
