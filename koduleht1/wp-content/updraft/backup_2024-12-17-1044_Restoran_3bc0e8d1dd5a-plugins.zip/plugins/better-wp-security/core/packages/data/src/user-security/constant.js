export const STORE_NAME = 'ithemes-security/users';
export const path = '/wp/v2/users';
export const actionsPath = '/ithemes-security/v1/user-actions';
