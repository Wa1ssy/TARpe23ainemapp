export const STORE_NAME = 'ithemes-security/trusted-devices';
export const path = '/ithemes-security/v1/trusted-devices';
