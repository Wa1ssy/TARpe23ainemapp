export const STORE_NAME = 'ithemes-security/patchstack';
export const path = 'https://itsec-site-scanner.ithemes.com';
