export function FlexSpacer() {
	return <div style={ { flexGrow: 1 } } aria-hidden className="itsec-component-flex-spacer" />;
}
