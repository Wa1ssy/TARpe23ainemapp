export const STORE_NAME = 'ithemes-security/site-scanner';
export const path = '/ithemes-security/v1/site-scanner/scans';
